<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body class="bg-light">

<%
    String user = (String) session.getAttribute("user");

    if(user == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
    <div class="container">
        <a class="navbar-brand fw-bold">Diagnostic Lab</a>

        <div>
            <span class="text-white me-3">
                Welcome, <%= user %>
            </span>
            <a href="logout" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<!-- Success Message -->
<%
    String msg = request.getParameter("msg");
    if("success".equals(msg)){
%>
<div class="container mt-3">
    <div class="alert alert-success text-center">
        Booking Successful!
    </div>
</div>
<%
    }
%>
<div class="container mt-4 text-center">
    <a href="index.jsp" class="btn btn-outline-primary">
        Back to Home
    </a>
</div>

<!-- Header -->
<div class="container text-center mt-4">
    <h2 class="text-primary fw-bold">Dashboard</h2>
    <p class="text-muted">Manage your tests and bookings</p>
</div>

<!-- Cards -->
<div class="container mt-4">
    <div class="row g-4">

        <!-- Book Test -->
        <div class="col-md-4">
            <div class="card shadow-lg border-0 text-center p-4">
                <i class="bi bi-clipboard-plus text-warning" style="font-size: 40px;"></i>
                <h5 class="mt-3">Book Test</h5>
                <p class="text-muted">Schedule a new test</p>
                <a href="book.jsp" class="btn btn-warning w-100">Book Now</a>
            </div>
        </div>

        <!-- My Bookings -->
        <div class="col-md-4">
            <div class="card shadow-lg border-0 text-center p-4">
                <i class="bi bi-journal-check text-success" style="font-size: 40px;"></i>
                <h5 class="mt-3">My Bookings</h5>
                <p class="text-muted">View your bookings</p>
                <a href="myBookings" class="btn btn-success w-100">View</a>
            </div>
        </div>

        <!-- Profile -->
        <div class="col-md-4">
            <div class="card shadow-lg border-0 text-center p-4">
                <i class="bi bi-person-circle text-primary" style="font-size: 40px;"></i>
                <h5 class="mt-3">My Profile</h5>
                <p class="text-muted">Check your details</p>
                <a href="myProfile.jsp" class="btn btn-primary w-100">Profile</a>
            </div>
        </div>

    </div>
</div>

<!-- Extra Section -->
<div class="container mt-5">
    <div class="card p-4 shadow text-center bg-white">
        <h5 class="text-danger">Popular Tests</h5>
        <p class="text-muted">Blood Test | Thyroid | Diabetes</p>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center p-3 mt-5">
    <p>© 2026 UU Diagnose Hub | All Rights Reserved</p>
</footer>

<!-- Auto-hide success message -->
<script>
    setTimeout(() => {
        let alert = document.querySelector('.alert');
        if(alert) alert.style.display = 'none';
    }, 3000);
</script>

</body>
</html>