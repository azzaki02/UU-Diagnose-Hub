<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>UU Diagnose Hub</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
   

    <style>
        body {
            background: linear-gradient(135deg, #00c6ff, #0072ff);
            height: 100vh;
        }

        .card {
            border-radius: 15px;
        }

        .form-control {
            border-radius: 10px;
        }

        .btn-custom {
            border-radius: 10px;
            font-weight: bold;
        }
    </style>
</head>

<body>

<div class="container d-flex justify-content-center align-items-center vh-100">

    <div class="row w-100">

        <!-- USER LOGIN -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-lg p-4">

                <div class="text-center mb-3">
                    <i class="bi bi-person-circle text-primary" style="font-size: 40px;"></i>
                    <h4>User Login</h4>
                </div>

                <%
                    String msg = request.getParameter("msg");
                    if("userError".equals(msg)){
                %>
                <div class="alert alert-danger text-center">
                    Invalid User Credentials
                </div>
                <%
                    }
                %>
                <%
    String mg = request.getParameter("msg");
    if ("wrong".equals(mg)) {
%>
<div class="alert alert-danger text-center">
    Wrong password or email
</div>
<%
    }
%>

                <form action="login" method="post">

                    <div class="mb-3">
                        <input type="email" name="email" class="form-control" placeholder="Enter Email" required>
                    </div>

                    <div class="mb-3">
                        <input type="password" name="password" class="form-control" placeholder="Enter Password" required>
                    </div>

                    <button class="btn btn-primary w-100 btn-custom">User Login</button>

                </form>

                <div class="text-center mt-3">
                    <a href="register.jsp">New User? Register</a>
                </div>
                <div class="container mt-4 text-center">
    <a href="index.jsp" class="btn btn-outline-primary">
        Back to Home
    </a>
</div>

            </div>
        </div>

        <!-- ADMIN LOGIN -->
        <div class="col-md-6">
            <div class="card shadow-lg p-4">

                <div class="text-center mb-3">
                    <i class="bi bi-shield-lock text-danger" style="font-size: 40px;"></i>
                    <h4>Admin Login</h4>
                </div>

                <%
                    if("adminError".equals(msg)){
                %>
                <div class="alert alert-danger text-center">
                    Invalid Admin Credentials
                </div>
                <%
                    }
                %>
                <%
    String ms = request.getParameter("msg");
    if("error".equals(ms)){
%>
<div class="alert alert-danger text-center">
    Wrong email or password
</div>
<%
    }
%>


                <form action="adminLogin" method="post">

                    <div class="mb-3">
                        <input type="text" name="id" class="form-control" placeholder="Enter Admin ID" required>
                    </div>

                    <div class="mb-3">
                        <input type="password" name="pass" class="form-control" placeholder="Enter Password" required>
                    </div>

                    <button class="btn btn-danger w-100 btn-custom">Admin Login</button>

                </form>

            </div>
        </div>

    </div>

</div>


</body>
</html>