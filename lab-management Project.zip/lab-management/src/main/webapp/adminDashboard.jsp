<%@ page contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body class="bg-light">

<%
    String admin = (String) session.getAttribute("admin");

    if(admin == null){
        response.sendRedirect("admin.jsp");
        return;
    }
%>

<!-- 🔷 Navbar -->
<nav class="navbar navbar-dark bg-dark shadow">
    <div class="container-fluid">
        <span class="navbar-brand fw-bold">Admin Panel</span>

        <div>
            <span class="text-white me-3">Welcome, Admin</span>
            <a href="logout" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>
</nav>

<!-- 🔷 Sidebar + Content -->
<div class="container-fluid">
    <div class="row">

        <!-- Sidebar -->
        <div class="col-md-2 bg-dark text-white vh-100 p-3">
            <h5 class="text-center mb-4">Menu</h5>

            <a href="viewUsers" class="d-block text-white mb-3 text-decoration-none">
                <i class="bi bi-people"></i> View Users
            </a>

            <a href="viewBookings" class="d-block text-white mb-3 text-decoration-none">
                <i class="bi bi-journal-text"></i> View Bookings
            </a>

            <a href="#" class="d-block text-white mb-3 text-decoration-none">
                <i class="bi bi-gear"></i> Settings
            </a>
        </div>

        <!-- Main Content -->
        <div class="col-md-10 p-4">

            <h2 class="mb-4">Dashboard Overview</h2>

            <div class="row g-4">

                <!-- Card 1 -->
                <div class="col-md-4">
                    <div class="card shadow border-0 p-4 text-center">
                        <i class="bi bi-people-fill text-primary" style="font-size: 40px;"></i>
                        <h4 class="mt-2">Users</h4>
                        <p>Total registered users</p>
                        <a href="viewUsers" class="btn btn-primary">View</a>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="col-md-4">
                    <div class="card shadow border-0 p-4 text-center">
                        <i class="bi bi-journal-check text-success" style="font-size: 40px;"></i>
                        <h4 class="mt-2">Bookings</h4>
                        <p>All test bookings</p>
                        <a href="viewBookings" class="btn btn-success">View</a>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="col-md-4">
                    <div class="card shadow border-0 p-4 text-center">
                        <i class="bi bi-bar-chart text-danger" style="font-size: 40px;"></i>
                        <h4 class="mt-2">Reports</h4>
                        <p>Analytics & reports</p>
                        <a href="#" class="btn btn-danger">View</a>
                    </div>
                </div>

            </div>

        </div>

    </div>
</div>

</body>
</html>