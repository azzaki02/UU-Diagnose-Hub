<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Book Test</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<%
    String user = (String) session.getAttribute("user");

    if(user == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!-- 🔷 Navbar -->
<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand">Book Test</a>
        <a href="dashboard.jsp" class="btn btn-light btn-sm">Back</a>
    </div>
</nav>

<!-- 🔷 Booking Form -->
<div class="container mt-5">

    <div class="card shadow p-4 mx-auto" style="max-width: 500px;">
        <h3 class="text-center text-success mb-4">Select Your Test</h3>

        <form action="book" method="post">

            <!-- Test Selection -->
            <div class="mb-3">
                <label class="form-label">Choose Test</label>
                <select name="test" class="form-select" required>
                    <option value="">-- Select Test --</option>
                    <option value="Blood Test">Blood Test - ₹500</option>
                    <option value="Thyroid Test">Thyroid Test - ₹800</option>
                    <option value="Diabetes Test">Diabetes Test - ₹600</option>
                </select>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-success w-100">
                Book Now
            </button>

        </form>

    </div>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>