<%@ page import="java.sql.*" %>
<%@ page import="com.lab.dao.DBConnection" %>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body class="bg-light">

<%
    String email = (String) session.getAttribute("user");

    if(email == null){
        response.sendRedirect("login.jsp");
        return;
    }

    String name = "";

    try {
        Connection con = DBConnection.getConnection();

        PreparedStatement ps = con.prepareStatement(
            "SELECT name, email FROM users WHERE email=?"
        );

        ps.setString(1, email);

        ResultSet rs = ps.executeQuery();

        if(rs.next()){
            name = rs.getString("name");
            email = rs.getString("email");
        }

    } catch(Exception e){
        e.printStackTrace();
    }
%>

<!-- 🔷 Navbar -->
<nav class="navbar navbar-dark bg-primary shadow">
    <div class="container">
        <a class="navbar-brand">My Profile</a>
        <a href="dashboard.jsp" class="btn btn-light btn-sm">Back</a>
    </div>
</nav>

<!-- 🔷 Profile Card -->
<div class="container mt-5 d-flex justify-content-center">

    <div class="card shadow-lg p-4 text-center" style="width: 400px; border-radius: 15px;">
        
        <!-- Avatar -->
        <i class="bi bi-person-circle text-primary" style="font-size: 80px;"></i>

        <h3 class="mt-3"><%= name %></h3>
        <p class="text-muted"><%= email %></p>

        <hr>

        <!-- Info -->
        <div class="text-start">
            <p><strong>Name:</strong> <%= name %></p>
            <p><strong>Email:</strong> <%= email %></p>
        </div>

        <!-- Buttons -->
        <a href="dashboard.jsp" class="btn btn-primary w-100 mt-3">Back to Dashboard</a>
    </div>

</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center p-3 mt-5">
    <p>© 2026 UU Diagnose Hub</p>
</footer>

</body>
</html>