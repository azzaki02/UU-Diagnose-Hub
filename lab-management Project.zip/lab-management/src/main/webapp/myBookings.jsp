<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.util.*" %>

<!DOCTYPE html>
<html>
<head>
    <title>My Bookings</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<%
    String user = (String) session.getAttribute("user");

    if(user == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!-- Navbar -->
<nav class="navbar navbar-dark bg-primary shadow">
    <div class="container">
        <a class="navbar-brand">My Bookings</a>
        <a href="dashboard.jsp" class="btn btn-light btn-sm">Back</a>
    </div>
</nav>

<!-- Header -->
<div class="container mt-4 text-center">
    <h2 class="text-success">Your Booked Tests</h2>
    <p class="text-muted">Here are all your booked lab tests</p>
</div>

<!-- Table -->
<div class="container mt-4">
    <div class="card shadow p-4">

        <table class="table table-bordered table-striped text-center">

            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Test Name</th>
                </tr>
            </thead>

            <tbody>
            <%
                ArrayList<String> list = (ArrayList<String>) request.getAttribute("bookings");

                if(list != null && list.size() > 0){
                    int i = 1;
                    for(String test : list){
            %>

            <tr>
                <td><%= i++ %></td>
                <td><%= test %></td>
            </tr>

            <%
                    }
                } else {
            %>

            <tr>
                <td colspan="2">No bookings found</td>
            </tr>

            <%
                }
            %>
            </tbody>

        </table>

    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center p-3 mt-5">
    <p>© 2026 UU Diagnose Hub</p>
</footer>

</body>
</html>