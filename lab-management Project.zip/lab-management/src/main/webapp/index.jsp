<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>UU Diagnose Hub</title>
    <meta charset="UTF-8">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand fw-bold">UU Diagnose Hub</a>

        <div>
            <a href="login.jsp" class="btn btn-outline-light me-2">Login</a>
            <a href="register.jsp" class="btn btn-warning">Register</a>
        </div>
    </div>
</nav>

<!-- Hero Section -->
<div class="bg-primary text-white text-center py-5">
    <div class="container">
        <h1 class="display-4 fw-bold">Book Your Lab Tests Online</h1>
        <p class="lead">Fast, Reliable & Affordable Diagnostic Services</p>
        <a href="register.jsp" class="btn btn-light btn-lg mt-3">Get Started</a>
    </div>
</div>

<!-- Services Section -->
<div class="container my-5">
    <h2 class="text-center mb-4 text-primary">Our Popular Tests</h2>

    <div class="row">

        <div class="col-md-4">
            <div class="card shadow text-center p-3">
                <h5>Blood Test</h5>
                <p>Accurate blood analysis</p>
                <button class="btn btn-success">₹500</button>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow text-center p-3">
                <h5>Thyroid Test</h5>
                <p>Check thyroid levels</p>
                <button class="btn btn-success">₹800</button>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow text-center p-3">
                <h5>Diabetes Test</h5>
                <p>Monitor sugar levels</p>
                <button class="btn btn-success">₹600</button>
            </div>
        </div>

    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white text-center py-3">
    <p>© 2026 UU Diagnose Hub | All Rights Reserved</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>