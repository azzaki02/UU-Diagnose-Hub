<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<link rel="stylesheet" href="css/style.css">
<body>
<h2>Admin Login</h2>

<form action="adminLogin" method="post">
    ID: <input type="text" name="id"><br><br>
    Password: <input type="password" name="pass"><br><br>

    <button type="submit">Login</button>
</form>

</body>
</html>