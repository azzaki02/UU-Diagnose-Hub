<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    <%@ page import="java.util.*" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>User Details</title>
</head>
<link rel="stylesheet" href="css/style.css">
<body>
<%@ page import="java.util.*, com.lab.model.User" %>

<%
    String admin = (String) session.getAttribute("admin");

    if(admin == null){
        response.sendRedirect("admin.jsp");
    }
%>


<h2>User Bookings</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Test Booked</th>
    </tr>

<%
    ArrayList<String[]> list = (ArrayList<String[]>) request.getAttribute("data");

    if(list != null){
        for(String[] row : list){
%>

<tr>
    <td><%= row[0] %></td>
    <td><%= row[1] %></td>
    <td><%= row[2] %></td>
</tr>

<%
        }
    }
%>

</table>

<br><br>

<a href="adminDashboard.jsp">Back</a>

</body>
</html>