package com.lab.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.lab.dao.DBConnection;

@WebServlet("/myBookings")
public class MyBookingsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // ✅ Check session
        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            res.sendRedirect("login.jsp");
            return;
        }

        // ✅ Get user email
        String email = (String) session.getAttribute("user");

        // ✅ List to store bookings
        ArrayList<String> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT test_name FROM bookings WHERE user_email=?"
            );

            ps.setString(1, email);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(rs.getString("test_name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // ✅ Send data to JSP
        req.setAttribute("bookings", list);

        // ✅ Forward to JSP
        req.getRequestDispatcher("myBookings.jsp").forward(req, res);
    }
}