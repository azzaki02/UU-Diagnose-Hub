package com.lab.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.lab.dao.DBConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/viewUsers")
public class ViewUsersServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // ✅ Check admin session
        HttpSession session = req.getSession(false);

        if (session == null || session.getAttribute("admin") == null) {
            res.sendRedirect("admin.jsp");
            return;
        }

        // ✅ List to store data
        ArrayList<String[]> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            // ✅ JOIN query (User + Booked Test)
            PreparedStatement ps = con.prepareStatement(
                "SELECT u.name, u.email, b.test_name " +
                "FROM users u " +
                "LEFT JOIN bookings b ON u.email = b.user_email"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String name = rs.getString("name");
                String email = rs.getString("email");
                String test = rs.getString("test_name");

                // Handle null (if no booking)
                if (test == null) {
                    test = "No Test Booked";
                }

                list.add(new String[]{name, email, test});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // ✅ Send data to JSP
        req.setAttribute("data", list);
        req.getRequestDispatcher("viewUsers.jsp").forward(req, res);
    }
}