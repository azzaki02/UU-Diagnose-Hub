package com.lab.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.lab.dao.DBConnection;

/**
 * Servlet implementation class BookTestServlet
 */
@WebServlet("/book")
public class BookTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private ServletRequest req;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookTestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {

	    res.setContentType("text/html");
	    PrintWriter out = res.getWriter();

	    // ✅ use req directly
	    String email = (String) req.getSession().getAttribute("user");
	    String test = req.getParameter("test");

	    try {
	        Connection con = DBConnection.getConnection();

	        PreparedStatement ps = con.prepareStatement(
	            "INSERT INTO bookings(user_email,test_name) VALUES(?,?)"
	        );

	        ps.setString(1, email);
	        ps.setString(2, test);

	        int i = ps.executeUpdate();
	        out.println("Booked Successfully"); 
	        if(i > 0){
	            res.sendRedirect("dashboard.jsp?msg=success"); // ✅ HERE
	            
	        } else {
	            res.sendRedirect("book.jsp?msg=error");
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	        res.sendRedirect("book.jsp?msg=error");
	    }
	}
}
