package com.lab.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/adminLogin")
public class AdminLoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {

	    res.sendRedirect("admin.jsp");
	}

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // ✅ USE req directly (DO NOT DECLARE AGAIN)
        String id = req.getParameter("id");
        String pass = req.getParameter("pass");

        if(id.equals("admin") && pass.equals("1234")) {

            HttpSession session = req.getSession();
            session.setAttribute("admin", id);

            res.sendRedirect("adminDashboard.jsp");

        }else {
            res.sendRedirect("login.jsp?msg=error");
        }
    }
}